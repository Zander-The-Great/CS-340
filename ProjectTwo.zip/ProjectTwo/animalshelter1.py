from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

#global variables
userCreateData = {}   #holds data for write function
userUpdateFromTarget = {}  #holds data for update function
userUpdateToTarget = {}  #holds  data for update function
userSearchTarget = {}  #holds data for search function
userDeleteTarget = {}  #holds data for delete function


class AnimalShelter(object):
    """CRUD Operations for Animal collection in MongoDB"""
    def __init__(self, user, password):
            # Initialize Mongo
            self.client = MongoClient('mongodb://%s:%s@localhost:37531/aac' % (user, password))
            self.database = self.client['aac']

    #obtain data from user (Create)
    def obtainCreateData(self):
        #table to ensure data diction conforms to format
        values = ['1', 'age_upon_outcome', 'animal_id', 'animal_type', 'breed', 'color', 'date_of_birth', 'datetime', 
          'monthyear', 'name', 'outcome_subtype', 'outcome_type', 'sex_upon_outcome', 'location_lat', 
          'location_long', 'age_upon_outcome_in_weeks']
        #loop obtain input from the user
        for x in range (len(values)):
            key = values[x]
            value = input("Enter " + values[x] + ": ")
            userCreateData.update({key: value})     
        
    #C operation for C in CRUD        
    def create(self, data):
        try:
            if data is not None:
                insert_result = self.database.animals.insert_one(data)    
                pprint(insert_result)
                return True   
            
            else:
                raise Exception("Cannot save, data parameter is empty")
        except:
            return False    
            
    #obtain data for R in CRUD
    def obtainReadData(self):
        for x in range(1):
            key = input("Enter search key: ")
            value = input("Enter search value: ")
            userSearchTarget.update({key: value})    

    #R operation for R in CRUD
    def read(self, target):
        try:
            if target is not None:
                read_result = list(self.database.animals.find(target, {"_id": False}))
                return read_result
            else:
                raise Exception("Cannot search, parameter is empty")
                return False
        except Exception as i:
            print("exception occurred: ", i)
    
    #obtain data for U in CRUD
    def obtainUpdateData(self):
        #loop for key/value pair
        for x in range(1):
            key = input("Enter update key: ")
            value = input("Enter updated value: ")
        userUpdateFromTarget.update({key: value})
        #obtain new data to change the target to
        for x in range(1):
            key = input("Enter update key: ")
            value = input("Enter new updated value: ")
        userUpdateToTarget.update({'$set': {key: value}})
        print(userUpdateToTarget)

    #U operation for U in CRUD
    def update(self, fromTarget, toTarget, count):
        if fromTarget is not None:
            if count == 1:
                update_result = self.database.animals.update_one(fromTarget, toTarget)
                pprint("Matched Count: " + str(update_result.matched_count) + ", Mod Count: " + str(update_result.modified_count))
                if update_result.modified_count == 1:
                    print("Success")
                    print(update_result)
                    return True
                else:
                    print("Something went wrong")
                    return False
            elif count == 2:
                update_result = self.database.animals.update_many(fromTarget, toTarget)
                pprint("Matched Count: " + str(update_result.matched_count) + ", Modified Count: " + str(update_result.modified_count))
                if update_result.modified_count == update_result.matched_count:
                    print("Success!")
                    print(update_result)
                    return True
                else:
                    print("Error, items may not have been updated. Run a search to verify")
                    print(update_result)
                    return True
            else:
                print("Count not recognized - try again.")
                return False
        else:
            #lets the user know there was a problem
            raise Exception("Nothing to update, because at least one of the target parameters is empty")
            return False
        
    #obtain target data for D in CRUD
    def obtainDeleteData(self):
        #loop for key/value pair
        for i in range(1):
            key = input("Enter delete key: ")
            value = input("Enter delete value: ")
            userDeleteTarget.update({key: value})
    #delete function for either single or many
    def deleteData(self, target, count):
        if target is not None:
            if count == 1:
                try:
                    delete_result = self.database.animals.delete_one(target)
                    pprint("Deleted Count: " + str(delete_result.deleted_count))
                    if delete_result.deleted_count == 0:
                        print("Nothing was deleted using data.")
                        print(delete_result)
                        return True
                    else:
                        print("Success")
                        print(delete_result)
                        return True
                except Exception as i:
                    print("An exception has occurred: ", i)
            elif count == 2:
                try:
                    delete_result = self.database.animals.delete_many(target)
                    pprint("Delete Count: " + str(delete_result.deleted_count))
                    if delete_result.deleted_count == 0:
                        print("Nothing to be deleted using the target data.")
                        print(delete_result)
                        return True
                    else:
                        print("Success")
                        print(delete_result)
                        return True
                except Exception as i:
                    print("An exception has occurred: ", i)
                    return False
            else:
                print("error recognized - try again.")
                return False
        else:
            raise Exception("target empty")
            return False